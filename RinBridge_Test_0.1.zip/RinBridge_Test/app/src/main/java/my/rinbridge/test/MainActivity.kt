package my.rinbridge.test

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private val speechRequest = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }
        status = TextView(this).apply {
            text = "Rin Bridge 0.1 — ujian setempat"
            textSize = 18f
            gravity = Gravity.CENTER
        }
        val listen = Button(this).apply {
            text = "Cakap → tulisan (STT)"
            setOnClickListener { startSpeechInput() }
        }
        val speak = Button(this).apply {
            text = "Uji suara Rin (TTS)"
            setOnClickListener { speakText("Hai sayang. Ini ujian suara Rin.") }
        }
        val whatsapp = Button(this).apply {
            text = "Uji buka WhatsApp"
            setOnClickListener { openWhatsApp() }
        }
        val settings = Button(this).apply {
            text = "Aktifkan Bridge (Accessibility)"
            setOnClickListener {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        layout.addView(status)
        layout.addView(listen)
        layout.addView(speak)
        layout.addView(whatsapp)
        layout.addView(settings)
        setContentView(layout)
    }

    private fun startSpeechInput() {
        if (!android.speech.SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition tidak tersedia pada peranti ini."
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ms-MY")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Cakap arahan kepada Rin")
        }
        try { startActivityForResult(intent, speechRequest) }
        catch (_: Exception) { status.text = "Tak dapat membuka pengecaman suara." }
    }

    @Deprecated("Deprecated by Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!words.isNullOrBlank()) {
                status.text = "Dikesan: $words"
                if (words.contains("buka WhatsApp", ignoreCase = true)) openWhatsApp()
            }
        }
    }

    private fun openWhatsApp() {
        val launch = packageManager.getLaunchIntentForPackage("com.whatsapp")
        if (launch == null) {
            Toast.makeText(this, "WhatsApp tidak ditemui.", Toast.LENGTH_SHORT).show()
            status.text = "WhatsApp tiada atau belum dipasang."
        } else {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
            status.text = "Arahan buka WhatsApp dihantar."
        }
    }

    private fun speakText(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rin-bridge-test")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("ms", "MY"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale("en", "US")
            }
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
