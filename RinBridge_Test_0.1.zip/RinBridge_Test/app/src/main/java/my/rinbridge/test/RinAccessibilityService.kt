package my.rinbridge.test

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class RinAccessibilityService : AccessibilityService() {
    private var lastCommandAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val now = System.currentTimeMillis()
        if (now - lastCommandAt < 2500) return

        val collected = buildString {
            event.text?.forEach { append(it).append(' ') }
            event.contentDescription?.let { append(it).append(' ') }
        }
        if (collected.contains("RIN_BRIDGE:OPEN_WHATSAPP", ignoreCase = true)) {
            lastCommandAt = now
            val launch = packageManager.getLaunchIntentForPackage("com.whatsapp")
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(launch) }
                catch (_: Exception) {
                    Toast.makeText(this, "Android menyekat pembukaan automatik. Buka melalui butang ujian.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onInterrupt() { }
}
