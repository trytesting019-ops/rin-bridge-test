plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "my.rinbridge.test"
    compileSdk = 35
    defaultConfig {
        applicationId = "my.rinbridge.test"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "0.1-test"
    }
}
